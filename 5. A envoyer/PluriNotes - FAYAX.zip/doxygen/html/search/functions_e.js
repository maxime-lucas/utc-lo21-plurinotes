var searchData=
[
  ['xmlmanager',['XMLManager',['../class_x_m_l_manager.html#a19349e2a82700a5a0723adf4fb46c571',1,'XMLManager']]]
];

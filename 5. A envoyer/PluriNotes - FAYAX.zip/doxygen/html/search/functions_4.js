var searchData=
[
  ['generatecoupleid',['generateCoupleId',['../class_couple.html#a0577bc21460a23eb1df81013d8997ebd',1,'Couple']]],
  ['getallactivearticles',['getAllActiveArticles',['../class_x_m_l_manager.html#abf4daba9fee6d4c3f2041e245ede63d4',1,'XMLManager']]],
  ['getallactivemultimedia',['getAllActiveMultimedia',['../class_x_m_l_manager.html#abda1ebab4700649839911f41af664912',1,'XMLManager']]],
  ['getallactivetasks',['getAllActiveTasks',['../class_x_m_l_manager.html#aba309b6e486a2254cd0c0660489dee3f',1,'XMLManager']]],
  ['getallrelations',['getAllRelations',['../class_x_m_l_manager.html#a420fe1d75078919f81ff288e57bd3746',1,'XMLManager']]],
  ['getcouplebyid',['getCoupleByID',['../class_pluri_notes.html#a479bcef8e4418c9dd985e4d6b84263c2',1,'PluriNotes::getCoupleByID()'],['../class_x_m_l_manager.html#a253b969cb0ba2e7e9041a87de3377e6f',1,'XMLManager::getCoupleById()']]],
  ['getcurrentid',['getCurrentId',['../class_relation_manager.html#a15b5cdb71dcd9f7c9102e7540b597656',1,'RelationManager']]],
  ['getlastid',['getLastId',['../class_x_m_l_manager.html#a0831f1dc37cdfb3385b16f1271cd1078',1,'XMLManager']]],
  ['getlastrelationid',['getLastRelationId',['../class_x_m_l_manager.html#a3af464325d7e79e31f85c5e3493d09db',1,'XMLManager']]],
  ['getnotebyid',['getNoteByID',['../class_pluri_notes.html#a3b30f5eedeb5bdb931f93f2d3f01758a',1,'PluriNotes::getNoteByID()'],['../class_x_m_l_manager.html#a427be3db7c021dcd5cac5e5d8c89ee95',1,'XMLManager::getNoteById()']]],
  ['getnoteversionbyid',['getNoteVersionByID',['../class_pluri_notes.html#a00befacac91cfab0bbe2becc655de090',1,'PluriNotes']]],
  ['getrelationbyid',['getRelationByID',['../class_pluri_notes.html#ae81acd5787405f013868d74d59c504bd',1,'PluriNotes::getRelationByID()'],['../class_x_m_l_manager.html#ae900a4337faec6d77d45036b7c7c6d20',1,'XMLManager::getRelationByID()']]]
];

var searchData=
[
  ['activenotesmanager',['ActiveNotesManager',['../class_active_notes_manager.html',1,'']]],
  ['archivednotesmanager',['ArchivedNotesManager',['../class_archived_notes_manager.html',1,'']]],
  ['article',['Article',['../class_article.html',1,'']]]
];

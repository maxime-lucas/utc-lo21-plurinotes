var searchData=
[
  ['updatearticle',['updateArticle',['../class_x_m_l_manager.html#a02f8567da72f871ef2dd89befccc2a44',1,'XMLManager']]],
  ['updatecouplelabelbyid',['updateCoupleLabelById',['../class_x_m_l_manager.html#abbf14703ca331f6cfef148702731ade5',1,'XMLManager']]],
  ['updatemultimedia',['updateMultimedia',['../class_x_m_l_manager.html#a87ec2c0f01e948b78bd2d490e77a005a',1,'XMLManager']]],
  ['updatetask',['updateTask',['../class_x_m_l_manager.html#aa548b5809c161e19826d45ab26fdea54',1,'XMLManager']]]
];

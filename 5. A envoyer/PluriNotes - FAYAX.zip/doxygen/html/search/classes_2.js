var searchData=
[
  ['datetime',['Datetime',['../class_datetime.html',1,'']]],
  ['deletednotesmanager',['DeletedNotesManager',['../class_deleted_notes_manager.html',1,'']]]
];

var searchData=
[
  ['notesmanager',['NotesManager',['../class_notes_manager.html#ae76158ef3dc4866af94c1e562e9a5213',1,'NotesManager']]]
];

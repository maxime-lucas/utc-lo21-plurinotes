var searchData=
[
  ['deletebyid',['deleteByID',['../class_c___mainwindow.html#ab021fc536e0044acfc8d64f3fd739568',1,'C_Mainwindow']]],
  ['deletebyrelation',['deleteByRelation',['../class_relation_manager.html#affa3501529e6b1eaea3b707008177f65',1,'RelationManager']]],
  ['deletecouple',['deleteCouple',['../class_x_m_l_manager.html#a6f8ddacf2b06ccfc1cada15fc7af72a4',1,'XMLManager']]],
  ['deletecouplebyid',['deleteCoupleByID',['../class_c___mainwindow.html#a1a3b03c22255c386f4313917b2446843',1,'C_Mainwindow']]],
  ['deletefromarticle',['deleteFromArticle',['../class_x_m_l_manager.html#a12a73e294c2e82abadff626e7b2a8088',1,'XMLManager']]],
  ['deletefromcouple',['deleteFromCouple',['../class_x_m_l_manager.html#adbb2964549e070f2e18de22cf529cdda',1,'XMLManager']]],
  ['deletefrommultimedia',['deleteFromMultimedia',['../class_x_m_l_manager.html#a3bf565f2d3a344134fdfe8346ab62a33',1,'XMLManager']]],
  ['deletefromtask',['deleteFromTask',['../class_x_m_l_manager.html#a1e8a9cbcebdc2a1ff152bed6f5d5a20a',1,'XMLManager']]],
  ['deletenote',['deleteNote',['../class_v___central_note.html#a337f6b0ffbde3e48db5523db97aadd8d',1,'V_CentralNote']]],
  ['deletenoteversion',['deleteNoteVersion',['../class_c___mainwindow.html#a5d1368e009595d8ab747d2a33818158a',1,'C_Mainwindow::deleteNoteVersion()'],['../class_x_m_l_manager.html#ad8881c11366b4d6842a8ad889650e5f8',1,'XMLManager::deleteNoteVersion()']]],
  ['deleterelation',['deleteRelation',['../class_x_m_l_manager.html#a15130d15c867274d9ad6d4c3476bf25f',1,'XMLManager']]],
  ['deleterelationbyid',['deleteRelationByID',['../class_c___mainwindow.html#ad56ff3fbace81f3ee74fabfe1cbc5bc5',1,'C_Mainwindow']]],
  ['deleteview',['deleteView',['../class_v___central_view.html#a70fcf62d2f4d0467738db3984900b64f',1,'V_CentralView']]]
];

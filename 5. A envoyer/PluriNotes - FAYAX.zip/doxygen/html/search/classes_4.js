var searchData=
[
  ['note',['Note',['../class_note.html',1,'']]],
  ['notesmanager',['NotesManager',['../class_notes_manager.html',1,'']]]
];

var searchData=
[
  ['editarticle',['editArticle',['../class_c___mainwindow.html#afb21301696492d974523e1d590a420d7',1,'C_Mainwindow::editArticle()'],['../class_v___central_article.html#aeec003a4e6a601b648f7bfd44ee4a40e',1,'V_CentralArticle::editArticle()']]],
  ['editcouple',['editCouple',['../class_c___mainwindow.html#a2476821eb7e7ed907443346e0728e90e',1,'C_Mainwindow::editCouple()'],['../class_v___central_couple.html#ad91e31930a85d7d3c476d804a1a6203c',1,'V_CentralCouple::editCouple()']]],
  ['editmultimedia',['editMultimedia',['../class_c___mainwindow.html#ae60cb3f871f424f2d16264a7cecb18de',1,'C_Mainwindow::editMultimedia()'],['../class_v___central_multimedia.html#a4a725c27fe7cb845c1c1fbe2cfad731f',1,'V_CentralMultimedia::editMultimedia()']]],
  ['editnote',['editNote',['../class_v___central_note.html#a4ceb63417f2cb8705e1b54ed7b1199b6',1,'V_CentralNote']]],
  ['editrelation',['editRelation',['../class_c___mainwindow.html#a3c496f14d372b052c26957e93e0a4635',1,'C_Mainwindow::editRelation()'],['../class_v___centralrelation.html#ae0379a8de1ad8844c0435161c5015a6b',1,'V_Centralrelation::editRelation()']]],
  ['edittask',['editTask',['../class_c___mainwindow.html#a2dda665e3cf40884d45fe954d48c043e',1,'C_Mainwindow::editTask()'],['../class_v___central_task.html#a31bb54e8002fb073d2c15a02ddd62457',1,'V_CentralTask::editTask()']]],
  ['editview',['editView',['../class_v___central_view.html#abeb93b7d4ee2f8d9df81fef40d03a036',1,'V_CentralView']]]
];

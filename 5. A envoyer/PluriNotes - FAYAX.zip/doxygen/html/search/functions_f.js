var searchData=
[
  ['_7exmlmanager',['~XMLManager',['../class_x_m_l_manager.html#ae89ae1837bd192daa5e295d95dd1edc1',1,'XMLManager']]]
];

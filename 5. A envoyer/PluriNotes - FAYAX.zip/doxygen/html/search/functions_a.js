var searchData=
[
  ['savenewarticle',['saveNewArticle',['../class_c___mainwindow.html#accb87506fc500835b8b007cdb439fa4a',1,'C_Mainwindow']]],
  ['savenewmultimedia',['saveNewMultimedia',['../class_c___mainwindow.html#a0b529e5f3fb2e627d11a810a4232520e',1,'C_Mainwindow']]],
  ['savenewrelation',['saveNewRelation',['../class_c___mainwindow.html#a378db3539d221153aaa78c466307dd69',1,'C_Mainwindow']]],
  ['savenewtask',['saveNewTask',['../class_c___mainwindow.html#a5498b6fcb70640542e1016755fd2ce79',1,'C_Mainwindow']]],
  ['setemptycentralview',['setEmptyCentralView',['../class_v___main_view.html#a74a92088217b2d3fbfe348cb0efc45d6',1,'V_MainView']]],
  ['setemptylist',['setEmptyList',['../class_v___main_view.html#a830fe68c4847cf7a4ce551f4888674e7',1,'V_MainView']]],
  ['setisrelationview',['setIsRelationView',['../class_v___central_view.html#a973860b4389f38914c7122eabe7f7f8f',1,'V_CentralView']]]
];

var searchData=
[
  ['refreshactivenotes',['refreshActiveNotes',['../class_c___mainwindow.html#a3035846779f1668d56904fddb1dee856',1,'C_Mainwindow']]],
  ['refreshcouple',['refreshCouple',['../class_v___main_view.html#a298d9b6e13c3d09aa48dd0cc9eaba094',1,'V_MainView']]],
  ['refreshlistcouple',['refreshListCouple',['../class_v___main_view.html#a2cb1a6e93b4ed8d3dcc8bd714d12600a',1,'V_MainView']]],
  ['refreshrelation',['refreshRelation',['../class_v___main_view.html#a938e2618831473547df3cda8d57a7432',1,'V_MainView']]],
  ['refreshtask',['refreshTask',['../class_c___mainwindow.html#aafa620cdab76d86f76cbd9c6e6a6bf12',1,'C_Mainwindow']]],
  ['reloadfromdatabase',['reloadFromDatabase',['../class_pluri_notes.html#a22c45c033e457605014fcb4541ccd7be',1,'PluriNotes']]],
  ['resetdocument',['resetDocument',['../class_x_m_l_manager.html#ac321b29dd891ae22adb0d06454373763',1,'XMLManager']]],
  ['restorenoteversion',['restoreNoteVersion',['../class_c___mainwindow.html#ae6a7d88015086d2b619e5f7a71e27655',1,'C_Mainwindow::restoreNoteVersion()'],['../class_x_m_l_manager.html#ac471ffe295eb769a57e510e27e0df178',1,'XMLManager::restoreNoteVersion()']]]
];

var searchData=
[
  ['plurinotes',['Plurinotes',['../class_plurinotes.html',1,'Plurinotes'],['../class_pluri_notes.html',1,'PluriNotes']]]
];

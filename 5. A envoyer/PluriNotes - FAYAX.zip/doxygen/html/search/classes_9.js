var searchData=
[
  ['xmlmanager',['XMLManager',['../class_x_m_l_manager.html',1,'']]]
];
